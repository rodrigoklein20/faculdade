/* Primeiro programa em C
   elaborado pela Prof. Adriana Reis */
// Universidade Feevale

//bibliotecas
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
//fun��o principal
int main(void){//in�cio
    printf("Hello World!\n"); //equivale ao Escreva
    getch(); //captura enter do usu�rio
    return 0;
}//fim
