#include <stdio.h>
#include <stdlib.h>
/*
    Primeiro exemplo de Programa em C
    Algoritmos
*/
//Fun��o Principal
int main(){
    printf("Hello World!\n"); //instru��o para fazer a exibi��o em tela
    return 0;
}
